﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


    public class UserRole
    {
     //   public const string PORTER = "PORTER";
        public const string GUIDES = "GUIDES";
        public const string HEAD = "HEAD";
        public const string ADMIN = "ADMIN";
        public const string WATCHING = "WATCHING";
        public const string NONE = "NONE";
    }
