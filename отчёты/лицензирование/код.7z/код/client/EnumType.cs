﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets.myScript.button.TableRead
{
    enum EnumType: int
    {   
        NULL=0,
        REAL=1,
        READ=2,
        SET=3
    }
}
