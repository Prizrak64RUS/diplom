﻿using UnityEngine;
using System.Collections;

public class rowsRaspWrite : MonoBehaviour {

    public UnityEngine.UI.Text t_start;
    public UnityEngine.UI.Text t_end;

    public UnityEngine.UI.Text lec;
    public UnityEngine.UI.Text name;
    
}
